-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2019 at 05:50 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='for admin user only';

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `password`) VALUES
(2, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `name`, `image`, `price`) VALUES
(4, 'Redmi Note 7', 'N7.jpg', 11990.00),
(5, 'Redmi GO', 'G1.PNG', 13990.00),
(6, 'XIAOMI MI 9', 'MI9.PNG', 20990.00),
(7, 'Samsung Galaxy S10', 'G6.PNG', 21990.00),
(8, 'Samsung Galaxy S9', 'G4.PNG', 11990.00),
(9, 'Samsung Galaxy S8', 'G5.PNG', 8990.00),
(10, 'A50 Wireless Headset', 'H1.PNG', 7999.00),
(11, 'Bengoo G900', 'H2.PNG', 6999.00),
(12, 'ONIKUMA', 'H3.PNG', 5999.00),
(13, 'SA810', 'H4.PNG', 3555.00),
(14, 'Stealth 600', 'H5.PNG', 4999.56),
(19, 'UA Cap Teal', 'C2.JPG', 299.00),
(18, 'UA Cap Maroon', 'C1.JPG', 299.00),
(17, 'LS25', 'LS25.PNG', 1200.00),
(20, 'UA Cap Blue', 'C3.JPG', 299.00),
(21, 'UA Cap Navy Blue', 'C4.JPG', 299.00),
(42, '3D GS-6500', '3D GS-6500.png', 999.00),
(43, 'BOSCH TDA5072GB', 'BOSCH TDA5072GB.png', 1500.00),
(44, 'Bull refrigirator', 'Bull refrigirator.png', 5050.00),
(45, 'Cornell CIS18', 'Cornell CIS18.png', 799.00),
(46, 'Eveready TGC 3B', 'Eveready TGC 3B.png', 1499.00),
(47, 'Hobbs 22861', 'Hobbs 22861.png', 890.00),
(48, 'kenmore 51833', 'kenmore 51833.png', 7820.00),
(49, 'Nano Titanium Prima 3000', 'Nano Titanium Prima 3000.png', 1299.00),
(50, 'Nutid', 'Nutid.png', 11999.00),
(51, 'Omega OWM75W', 'Omega OWM75W.png', 21999.00),
(52, 'Pak fan', 'Pak Fan.png', 1299.00),
(53, 'Panasonic', 'Panasonic.png', 399.00),
(54, 'whirlpool 185', 'whirlpool 185.png', 13879.00),
(55, 'Samsung RF56M9540', 'Samsung RF56M9540.png', 15899.00),
(56, 'Sunbeam SR4315', 'Sunbeam SR4315.png', 699.00),
(57, 'Be Nice', '140_300x300_Front_Color-White (1).jpg', 299.00),
(58, 'Good Game', '140_300x300_Front_Color-White.jpg', 299.00),
(59, 'Bench Light Gray', 's_5b2825a82beb7940dbc1200d.jpeg', 399.00),
(60, 'Penshoppe Black Cap', 'Webp.net-resizeimage (1).png', 200.00),
(61, 'Penshoppe Illu Cap', 'Webp.net-resizeimage (2).png', 499.00),
(62, 'Penshoppe PinkBlack Cap', 'Webp.net-resizeimage (3).png', 289.00),
(63, 'Bench Lght', 'Webp.net-resizeimage.png', 299.00),
(64, 'Nike Hyperdunk', 'asdf-300x300.jpg', 3999.00),
(65, 'Lining ', 'abap005-2.jpg', 2999.00),
(66, 'Kyrie 5', 'Q0338_0221_right4.jpg', 4999.00),
(67, 'Nike ', 's-l300 (1).jpg', 4999.00),
(69, 'Kyrie 5 JustDoIt', 's-l300.jpg', 4599.00),
(70, 'Asus 90mp0081', 'Asus 90mp0081.jpg', 1999.00),
(71, 'Asus Rog Huracan', 'Asus Rog Huracan.jpg', 4999.00),
(72, 'black Corwn Garage', 'Black Corwn Garage.jpeg', 7999.00),
(73, 'Chaos Classic Core', 'Chaos Classic Core I3.png', 14000.00),
(74, 'G900 Chaos Spectrum', 'G900 Chaos Spectrum.jpg', 6000.00),
(75, 'Havit Wired USB 2.0', 'Havit Wired USB 2.0.jpg', 3000.00),
(76, 'Intel i9 PCs', 'Intel i9 PCs.jpg', 16000.00),
(87, 'Acer Predator', 'Acer Predator.jpg', 13999.00),
(78, 'Leather Recliner Sofa', 'Leather Recliner Sofa.jpg', 23000.00),
(79, 'Luxury Sofas', 'Luxury Sofas.jpg', 16000.00),
(80, 'Modular Sofas ', 'Modular Sofas.jpg', 13000.00),
(81, 'MSI Trident X', 'MSI Trident X.jpg', 43000.00),
(82, 'Outdoor Sofas', 'Outdoor Sofas.jpg', 12000.00),
(83, 'Razer', 'Razer.jpg', 699.00),
(84, 'Slab Cabinet', 'Slab Cabinet Doors Custom.jpg', 7999.00),
(85, 'Snuggler Sofa Chaise', 'Snuggler Sofa Chaise.jpg', 24000.00),
(86, 'Wittmann', 'Wittmann.jpg', 15000.00),
(88, 'AOPEN 24ML1Y', 'AOPEN 24ML1Y.gif', 26999.00),
(89, 'AOC G2460PF 144Hz', 'AOC G2460PF 144Hz.jpg', 6969.00),
(90, 'Asus MG248QR', 'Asus MG248QR 24.jpeg', 11000.00),
(91, 'Asus PG27VQ 27', 'Asus PG27VQ 27.jpg', 22000.00),
(92, 'Asus VE249Q Rog', 'Asus VE249Q Rog.jpg', 14000.00),
(93, 'LG 34UC89G-B', 'LG 34UC89G-B.jpg', 16000.00),
(94, 'LG UK6300', 'LG UK6300.jpg', 45000.00),
(95, 'Pyle-home Ptvled', 'Pyle-home Ptvled.jpg', 32000.00),
(96, 'A4 Tech Bloody B975', 'A4Tech Bloody B975.jpg', 1500.00);

-- --------------------------------------------------------

--
-- Table structure for table `tb_customer`
--

CREATE TABLE `tb_customer` (
  `id` int(11) NOT NULL,
  `fname` varchar(25) NOT NULL,
  `lname` varchar(25) NOT NULL,
  `uname` varchar(25) NOT NULL,
  `pass` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_customer`
--

INSERT INTO `tb_customer` (`id`, `fname`, `lname`, `uname`, `pass`) VALUES
(3, 'buyer', 'buyer', 'buyer', 'buyer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_customer`
--
ALTER TABLE `tb_customer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `tb_customer`
--
ALTER TABLE `tb_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
